# consignas-go-db

## Despliegue

Para empezar la ejecucion de la apliocac, ejecutamos el siguiente comando ubicados en la raiz del proyecto

<pre><code> go run cmd/server/main.go </code></pre>