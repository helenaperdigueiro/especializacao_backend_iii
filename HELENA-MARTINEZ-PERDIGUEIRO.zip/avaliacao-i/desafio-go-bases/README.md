# desafio-go-bases

## To test this application:

### In the main.go there are tests for 4 functions separated by fmt.Println("---")
### For better readability in the console, comment each function test (from fmt.Println("---") to fmt.Println("---")).