package tickets

type Ticket struct {
}

// exemplo 1
func GetTotalTickets(destination string) (int, error) {}

// exemplo 2
func GetMornings(time string) (int, error) {}

// exemplo 3
func AverageDestination(destination string, total int) (int, error) {}
